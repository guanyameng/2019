﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 灯光报警的控制
/// </summary>
public class LightAlarm : MonoSingleton<LightAlarm>
{

	#region 定义字段

	/// <summary>
	/// 警报灯光组件
	/// </summary>
	private Light m_alarmLight;

	/// <summary>
	/// 灯光的最强亮度
	/// </summary>
	private float m_highIntensity = 5.0f;
	private float m_weakIntensity = 1.0f;

	/// <summary>
	/// 灯光的最低强度
	/// </summary>
	private float m_lowIntensity = 0f;

	/// <summary>
	/// 目标灯光强度
	/// </summary>
	private float m_targetIntensity = 0f;

	/// <summary>
	/// 灯光切换的速度
	/// </summary>
	private float m_turnSpeed = 5.0f;

	/// <summary>
	/// 计时器
	/// </summary>
	private float timer = 3f;

	/// <summary>
	/// 关闭报警器标识符
	/// </summary>
	private bool isOpen;
	#endregion

	#region Unity回调

	protected override void Awake()
	{
		base.Awake();
		// 初始化灯光组件
		m_alarmLight = transform.GetComponent<Light>();
		// 先让目标灯光和最低灯光强度相等
		m_targetIntensity = m_lowIntensity;      
	}  

	void Update()
	{
		// 如果灯光是开启的
		if (isOpen)
		{
			// 灯光的灯光强度 = 灯光警报的强度
			m_alarmLight.intensity =
				Mathf.Lerp(m_alarmLight.intensity,
					m_targetIntensity, Time.deltaTime * m_turnSpeed);

			if (Mathf.Abs
				(m_alarmLight.intensity - m_targetIntensity) < 0.01f)
			{
				// 如果当前灯光是最大强度光，让它等于最低强度光
				if (m_targetIntensity == m_highIntensity)
				{
					m_targetIntensity = m_weakIntensity;

				}
				else
				{
					// 如果当前是最低灯光，那么让它等于最高
					m_targetIntensity = m_highIntensity;
				}
			}
		}
		else if (isOpen == false)
		{
			m_alarmLight.intensity = 0f;                                                                                 
		}
	}
	#endregion
	IEnumerator SendPost(string _url, WWWForm _wForm)
	{
		WWW postData = new WWW(_url, _wForm);
		yield return postData;
		if (postData.error != null)
		{
			Debug.Log(postData.error);
		}
		else
		{
			Debug.Log(postData.text);
		}
	}
	#region 灯光变化的方法

	/// <summary>
	/// 开启警报灯光
	/// </summary>
	public void OpenAlarmLight()
	{
		isOpen = true;
		WWWForm form = new WWWForm();
		form.AddField ("int", "8");
		StartCoroutine(SendPost("192.168.137.182:90", form));
	}

	/// <summary>
	/// 关闭灯光报警器
	/// </summary>
	public void CloseAlarmLight()
	{
		isOpen = false;
		WWWForm form = new WWWForm();
		form.AddField ("int", "9");
		StartCoroutine(SendPost("192.168.137.182:90", form));
	}

	#endregion
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 窗帘实现的方法，动画等
/// </summary>
public class Curtain : MonoBehaviour
{
	#region 定义的方法字段

	// 创建单例
	public static Curtain _instance;

	// 窗帘动画
	private Animator ant;
	#endregion

	#region Unity回调

	void Awake()
	{
		_instance = this;
		// 初始化动画组件
		ant = this.GetComponent<Animator>();
	}
	#endregion
	IEnumerator SendPost(string _url, WWWForm _wForm)
	{
		WWW postData = new WWW(_url, _wForm);
		yield return postData;
		if (postData.error != null)
		{
			Debug.Log(postData.error);
		}
		else
		{
			Debug.Log(postData.text);
		}
	}
	#region 方法

	/// <summary>
	/// 播放窗帘拉开的动画
	/// </summary>
	public void OpenCurtain()
	{
		ant.SetBool("Open",true);
		WWWForm form = new WWWForm();
		form.AddField ("int", "6");
		StartCoroutine(SendPost("192.168.137.182:90", form));
	}

	/// <summary>
	/// 播放窗帘关闭的动画
	/// </summary>
	public void CloseCurtain()
	{
		ant.SetBool("Open", false);
		WWWForm form = new WWWForm();
		form.AddField ("int", "7");
		StartCoroutine(SendPost("192.168.137.182:90", form));
	}

	#endregion
}

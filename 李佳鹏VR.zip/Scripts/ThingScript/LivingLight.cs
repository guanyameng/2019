﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
/// <summary>
/// 客厅灯光的控制
/// </summary>
public class LivingLight : MonoSingleton<LivingLight>
{
	#region 定义的方法变量

	/// <summary>
	/// 定义客厅灯光组件
	/// </summary>
	private Light m_light;
	#endregion

	#region Unity回调方法

	protected override void Awake()
	{
		base.Awake();
		// 初始化灯光组件
		m_light = this.GetComponent<Light>();      
	}

	#endregion

	#region 方法
	IEnumerator SendPost(string _url, WWWForm _wForm)
	{
		WWW postData = new WWW(_url, _wForm);
		yield return postData;
		if (postData.error != null)
		{
			Debug.Log(postData.error);
		}
		else
		{
			Debug.Log(postData.text);
		}
	}

	/// <summary>
	/// 控制灯光的开关
	/// </summary>
	/// <param name="isShow">控制开关的参数</param>
	public void IsShow(bool isShow)
	{
		if (isShow)
		{
			// 显示的话，让灯的亮度等于2
			m_light.intensity = 2f;
			WWWForm form = new WWWForm();
			form.AddField ("int", "3");
			StartCoroutine(SendPost("192.168.137.182:90", form));  
		}
		else
		{
			// 关闭的话，让灯的亮度等于0
			m_light.intensity = 0f;
			WWWForm form = new WWWForm();
			form.AddField ("int", "2");
			StartCoroutine(SendPost("192.168.137.182:90", form));  
		}

	}
	#endregion
}

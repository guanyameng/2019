﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 空调的动画
/// </summary>
public class Air_Condition : MonoBehaviour {
	#region 方法
	// 创建单例
	public static Air_Condition _instance;
	// 空调动画
	private Animator ani;
	#endregion

	#region Unity回调方法
	private void Awake()
	{
		_instance = this;
	}

	private void Start()
	{
		// 初始化动画组件
		ani = GetComponent<Animator>();
	}
	#endregion
	IEnumerator SendPost(string _url, WWWForm _wForm)
	{
		WWW postData = new WWW(_url, _wForm);
		yield return postData;
		if (postData.error != null)
		{
			Debug.Log(postData.error);
		}
		else
		{
			Debug.Log(postData.text);
		}
	}
	#region 方法
	/// <summary>
	/// 播放空调开启的动画
	/// </summary>
	public void OpenAir()
	{
		// 空调开的动画播放的条件
		ani.SetBool("OpenAir", true);
		WWWForm form = new WWWForm();
		form.AddField ("int", "4");
		StartCoroutine(SendPost("192.168.137.182:90", form));  
	}
	/// <summary>
	/// 关闭空调开启的动画
	/// </summary>
	public void CloseAir()
	{
		// 空调关闭的动画播放的条件
		ani.SetBool("OpenAir", false);
		WWWForm form = new WWWForm();
		form.AddField ("int", "5");
		StartCoroutine(SendPost("192.168.137.182:90", form));  
	}
	#endregion
}

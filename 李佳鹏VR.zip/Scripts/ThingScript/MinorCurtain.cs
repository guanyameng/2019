﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


/// <summary>
/// 次卧窗帘实现的方法，动画等
/// </summary>
public class MinorCurtain : MonoBehaviour {
	#region 定义的变量字段属性
	// 创建单例
	public static MinorCurtain _instance;

	// 窗帘动画
	private Animator ant;
	#endregion

	#region Unity回调方法
	void Awake()
	{
		_instance = this;
	}

	void Start()
	{
		// 初始化窗帘组件
		ant = this.GetComponent<Animator>();
	}
	#endregion

	#region 方法
	/// <summary>
	/// 播放窗帘拉开的动画
	/// </summary>
	public void OpenCurtain()
	{
		ant.SetFloat("Speed", 1.0f);
	}

	/// <summary>
	/// 播放窗帘关闭的动画
	/// </summary>
	public void CloseCurtain()
	{
		ant.SetFloat("Speed", -1.0f);
	}
	#endregion
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MinorBedRoomMove : MonoSingleton<MinorBedRoomMove> {
	#region 定义变量
	/// <summary>
	/// 定义动画组件
	/// </summary>
	private Animator anim;
	#endregion

	#region Unity回调方法
	/// <summary>
	/// 重写父类单例方法
	/// </summary>
	protected override void Awake()
	{
		base.Awake();
	}

	/// <summary>
	/// 初始化动画组件
	/// </summary>
	private void Start()
	{
		anim = this.GetComponent<Animator>();
	}
	#endregion

	#region 方法
	public void ControllDoor()
	{
		// 播放开门动画
		anim.SetBool("Open", true);
		// 等待3秒之后进入次卧
		Invoke("MoveIn", 3f);
		// 等待6秒之后播放关门动画
		Invoke("CloseDoor", 6f);
	}

	public void MoveLiving()
	{
		// 播放开门动画
		anim.SetBool("Open", true);
		// 等待3秒之后进入客厅
		Invoke("MoveBack", 3f);
		// 等待6秒之后门关闭
		Invoke("CloseDoor", 6f);
	}

	void MoveBack()
	{
		// 移动到客厅
		CameraMoveNav.instance.Move
		(CameraMoveNav.instance.targetGameObjectPosition["客厅"]);
	}

	/// <summary>
	/// 摄像机移动的方法
	/// </summary>
	void MoveIn()
	{
		// 先将之前的路径清除
		CameraMoveNav.instance.Clean();
		// 摄像机移动到次卧
		CameraMoveNav.instance.Move
		(CameraMoveNav.instance.targetGameObjectPosition["次卧"]);
	}

	/// <summary>
	/// 播放关门的动画
	/// </summary>
	void CloseDoor()
	{
		anim.SetBool("Open", false);
	}
	#endregion
}

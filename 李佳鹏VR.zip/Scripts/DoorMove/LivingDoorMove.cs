﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;


/// <summary>
/// 入户门的动画
/// </summary>
public class LivingDoorMove : MonoSingleton<LivingDoorMove> {
	#region 定义的字段属性
	/// <summary>
	/// 定义门的动画组件
	/// </summary>
	private Animator anim;
	#endregion

	#region Unity回调方法
	/// <summary>
	/// 实现继承父类的单例方法
	/// </summary>
	protected override void Awake()
	{
		base.Awake();
		// 初始化动画组件
		anim = this.GetComponent<Animator>();
	}
	#endregion

	#region 方法
	/// <summary>
	/// 控制门动画的播放
	/// </summary>
	IEnumerator SendPost(string _url, WWWForm _wForm)
	{
		WWW postData = new WWW(_url, _wForm);
		yield return postData;
		if (postData.error != null)
		{
			Debug.Log(postData.error);
		}
		else
		{
			Debug.Log(postData.text);
		}
	}
	public void ControllDoor()
	{
		// 播放开门的动画
		anim.SetBool("Open", true);
		// 摄像机3秒后移动到客厅内
		WWWForm form = new WWWForm();
		form.AddField ("int", "1");
		StartCoroutine(SendPost("192.168.137.182:90", form));  

		Invoke("MoveIn",3f);

		// 6秒后播放关门动画
		Invoke("CloseDoor",6f);

	}

	/// <summary>
	/// 摄像机移动的方法
	/// </summary>
	/// <param name="time">方法执行需要等待的时间</param>
	/// <returns>协程</returns>
	void  MoveIn()
	{
		// 先将之前的路径清除
		CameraMoveNav.instance.Clean();
		// 摄像机移动
		CameraMoveNav.instance.Move(CameraMoveNav.instance.targetGameObjectPosition["客厅"]);
	}

	/// <summary>
	/// 播放关门的动画
	/// </summary>
	void CloseDoor()
	{
		anim.SetBool("Open", false);
	}
    #endregion
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainBedRoomMove : MonoSingleton<MainBedRoomMove> {
	#region 定义的变量字段
	/// <summary>
	/// 定义动画组件
	/// </summary>
	private Animator anim;
	#endregion

	#region  Unity回调方法
	/// <summary>
	/// 实现继承父类的单例方法
	/// </summary>
	protected override void Awake()
	{
		base.Awake();
	}

	/// <summary>
	/// 初始化动画组件
	/// </summary>
	private void Start()
	{
		anim = this.GetComponent<Animator>();
	}
	#endregion

	#region 方法
	public void ControllDoor()
	{
		// 打开主卧门的动画
		anim.SetBool("Open", true);
		// 等待3 秒后进入主卧
		Invoke("MoveIn", 3f);
		// 等待6秒后，门播放关闭的动画
		Invoke("CloseDoor", 6f);
	}

	public void MoveLiving()
	{
		// 播放开门的动画
		anim.SetBool("Open", true);
		// 等待3秒后进入客厅
		Invoke("MoveBack", 3f);
		// 等待6秒后，播放门关闭的动画
		Invoke("CloseDoor", 6f);
	}

	void MoveBack()
	{
		// 移动到客厅
		CameraMoveNav.instance.Move
		(CameraMoveNav.instance.targetGameObjectPosition["客厅"]);
	}

	/// <summary>
	/// 摄像机移动的方法
	/// </summary>
	void MoveIn()
	{
		// 先将之前的路径清除
		CameraMoveNav.instance.Clean();
		// 摄像机移动
		CameraMoveNav.instance.Move
		(CameraMoveNav.instance.targetGameObjectPosition["主卧"]);
	}

	/// <summary>
	/// 播放关门的动画
	/// </summary>
	void CloseDoor()
	{
		anim.SetBool("Open", false);
	}
	#endregion

}

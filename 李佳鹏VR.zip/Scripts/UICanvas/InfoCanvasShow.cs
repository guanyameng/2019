﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InfoCanvasShow : MonoSingleton<InfoCanvasShow> {

    #region Unity回调

    protected override void Awake()
    {
        base.Awake();
        // 初始的时候为隐藏
        gameObject.SetActive(false);
    }

    #endregion

    #region 方法
    /// <summary>
    /// 图片是否显示
    /// </summary>
    /// <param name="isshow"></param>
    public void isShow(bool isshow)
    {
        gameObject.SetActive(isshow);
    }
    #endregion
}

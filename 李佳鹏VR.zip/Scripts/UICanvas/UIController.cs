﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// UI控制
/// </summary>
public class UIController : MonoBehaviour
{
    // 创建单例
    public static UIController _instance;

    void Awake()
    {
        _instance = this;
    }

    /// <summary>
    /// 当射线检测到的是On的按钮的时候，触发下列事件
    /// </summary>
    /// <param name="name">触发到的UI的父物体的名字</param>
    public void RespondOnUIEvent(string name)
    {
        // 检测开的图片的父物体
        switch (name)
        {
            // 如果点击了开的父物体是CurtainImage
            case "CurtainImage":
                {
                    // 如果是处于未连接设备装填
                 
                        // 直接开启窗帘的动画
                        Curtain._instance.OpenCurtain();
                    
                    
                    break;
                }
            // 如果点击的开的父物体是MainCurtainImage
            case "MainCurtainImage":
                {
                    // 播放主卧窗帘开启的动画
                    MainCurtain._instance.OpenCurtain();
                    break;
                }
            // 如果点击的开的父物体是MinorCurtainImage
            case "MinorCurtainImage":
                {
                    // 播放次卧窗帘开启的动画
                    MinorCurtain._instance.OpenCurtain();
                    break;
                }
            // 如果点击的开的父物体是AirConditionImage
            case "AirConditionImage":
                {
                    Air_Condition._instance.OpenAir();
                    break;
                }
            // 如果点击的开的父物体是AlarmImage
            case "AlarmImage":
                {
                    // 如果未连接设备
                   
                        LightAlarm.instance.OpenAlarmLight();
                    
                    break;
                }
            // 如果点击的开的父物体是LightImage
            case "LightImage":
                {
                    // 如果未连接设备
                    
                        // 灯光开启
                        LivingLight.instance.IsShow(true);
                    
                    break;
                }
            // 如果点击的开的父物体是FanImage
            
        }
    }

    /// <summary>
    /// 当射线检测到的是Off按钮的时候，触发以下事件
    /// </summary>
    /// <param name="name">触发到的UI的父物体的名字</param>
    public void RespondOffUIEvent(string name)
    {
        switch (name)
        {
            // 如果点击的关的父物体是CurtainImage
            case "CurtainImage":
                {
                    
                        Curtain._instance.CloseCurtain();
                    
                    
                    break;
                }
            // 如果点击的关的父物体是MainCurtainImage
            case "MainCurtainImage":
                {
                    MainCurtain._instance.CloseCurtain();
                    break;
                }
            // 如果点击的关的父物体是MinorCurtainImage
            case "MinorCurtainImage":
                {
                    MinorCurtain._instance.CloseCurtain();
                    break;
                }
            // 如果点击的关的父物体是AirConditionImage
            case "AirConditionImage":
                {
                    Air_Condition._instance.CloseAir();
                    break;
                }
            // 如果点击的关的父物体是AlarmImage
            case "AlarmImage":
                {
                    
                        LightAlarm.instance.CloseAlarmLight();
                    
                    break;
                }
            // 如果点击的关的父物体是LightImage
            case "LightImage":
                {
                    
                    
                        LivingLight.instance.IsShow(false);
                    
                    break;
                }
            // 如果点击的关的父物体是FanImage
            
        }
    }

    /// <summary>
    /// 控制UI面板的显示与关闭
    /// </summary>
    /// <param name="isShow"></param>
    public void IsShow(bool isShow)
    {
        gameObject.SetActive(isShow);
    }
}

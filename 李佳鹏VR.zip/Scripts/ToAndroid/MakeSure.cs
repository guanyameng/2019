﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;
// 注意：切换场景要引入UnityEngine.SceneManagement命名空间
using UnityEngine.SceneManagement;

///<summary>
/// 选择是否连接设备
///</summary>
public class MakeSure : MonoBehaviour
{
    #region 定义的变量字段和属性

    /// <summary>
    /// 单例
    /// </summary>
    public static MakeSure instance;

    [HideInInspector]
    public string linkState = "连接设备";

    public GameObject gameObj;

    #endregion

    #region Unity回调方法

    void Awake()
    {
        instance = this;
        
    }



    #endregion

    #region 方法

    /// <summary>
    /// 如果点击了确定，调用该方法
    /// </summary>
    public void SubStart()
    {
        // 先将连接状态改为连接
        PlayerPrefs.SetString(linkState, "确定");
        // 进入场景的时候就开始绑定服务
        UnityToAndroid.instance.InitBindService();
        Invoke("Waitting",2f);
    }

    void Waitting()
    {
        UnityToAndroid.instance.BindState();
        if (UnityToAndroid.instance.isBindSuccess == "BindSuccess")
        {
            //// 当点击了确定连接，下一步操作是获取设备列表
            //UnityToAndroid.instance.GetStates();
            //// 监听设备
            //UnityToAndroid.instance.SetDeviceList();
            //// 订阅设备
            //UnityToAndroid.instance.SubScribeDevice();

            ChangeScene();
        }
        
    }

    /// <summary>
    /// 等待一段时间，然后切换场景
    /// </summary>
    /// <param name="time">切换场景前执行的方法</param>
    /// <returns></returns>
    public void ChangeScene()
    {
        // 切换场景
        SceneManager.LoadScene("DevicesChoice", LoadSceneMode.Single);
        DontDestroyOnLoad(gameObj);
    }

    /// <summary>
    /// 点击取消的时候，调用该方法
    /// </summary>
    public void Cancle()
    {
        // 先将状态切换成为未连接
        PlayerPrefs.SetString(linkState, "取消");
        // 如果点击取消，不进行下一步操作，直接跳转场景
        // 切换场景
        SceneManager.LoadScene("Loading", LoadSceneMode.Single);
        DontDestroyOnLoad(gameObj);
    }

    #endregion
}
﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// 用于摄像机跟随
/// </summary>
public class CameraFollowMove1 : MonoBehaviour
{

	#region 定义的字段属性变量

	// 定义需要跟随的目标位置
	public Transform target;

	#endregion

	#region Unity回调方法

	void Update()
	{
		// 让摄像机实时利用插值到达目标位置
		transform.position = Vector3.Lerp
			(transform.position, target.position, Time.time);
	}

	#endregion
}



﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
/// <summary>
/// 通过VRResponse传递过来的参数，来判断是什么物体，实现什么操作
/// </summary>
/// 强制使用此脚本的游戏物体必须有Collider
[RequireComponent(typeof(Collider))]
public class VRComponent : MonoBehaviour
{
	#region 变量
	/// <summary>
	/// 交互需要等待的时间
	/// </summary>
	public float waitingTime = 1.5f;

	/// <summary>
	/// 在Inspector面板中隐藏
	/// 是否等待过
	/// </summary>
	[HideInInspector]
	public bool isWaitted = false;

	/// <summary>
	/// 门的动画播放的时间
	/// </summary>
	public float time = 3.5f;

	/// <summary>
	/// 创建单例
	/// </summary>
	public static VRComponent instance;

	public bool isBind = false;
	#endregion

	#region 方法

	private void Awake()
	{
		instance = this;
	}

	/// <summary>
	/// 射线检测之后响应的方法
	/// </summary>
	/// <param name="name">射线检测到的物体名字</param>
	/// <param name="trans">射线检测到的物体的Transform</param>
	public void ResponEvent(string name, Transform trans)
	{
		switch (name)
		{
		// 点击进门时的指纹机

		case "FoldImage":
			{
				// 控制动画收缩
				UIAnimation.instance.FoldOff();
				break;
			}
		case "OpenImage":
			{
				// 传递的参数是OpenImage的父物体的名字
				// 调用UIController脚本中的RespondOnUIEvent方法
				// RespondOnUIEvent会根据父物体的名字做出响应的方法
				UIController._instance.RespondOnUIEvent(trans.parent.name);
				break;
			}
			// 点击UI界面关的按钮
		case "CloseImage":
			{
				// 传递的参数是CloseImage的父物体的名字
				// 调用UIController脚本中的RespondOnUIEvent方法
				// RespondOnUIEvent会根据父物体的名字做出响应的方法
				UIController._instance.RespondOffUIEvent(trans.parent.name);
				break;
			}
			// 点击UI面板上的退出按钮
		case "BackImage":
			{
				// 隐藏UI面板
				UIController._instance.IsShow(false);
				break;
			}

		case "Romote":
			{
				// 显示客厅操作UI面板
				UICanvasShow.instance.IsShow();
				break;
			}

		case "LivingRoom":
			{
				// 客厅的门的控制
				LivingDoorMove.instance.ControllDoor();
				break;
			}
			// 点击进入厨房的开关
		case "DinnerRoom":
			{
				CameraMoveNav.instance.Move
				(CameraMoveNav.instance.targetGameObjectPosition["厨房"]);
				break;
			}
			// 点击进入卫生间的开关
		case "WashRoom":
			{
				WashRoomDoorMove.instance.ControllDoor();
				break;
			}
			// 点击进入主卧的开关
		case "MainBedRoom":
			{
				MainBedRoomMove.instance.ControllDoor();
				break;
			}
			// 点击进入次卧的开关
		case "MinorRoom":
			{
				MinorBedRoomMove.instance.ControllDoor();
				break;
			}
			// 点击进入书房的开关
		case "StudyRoom":
			{
				StudyRoomDoorMove.instance.ControllDoor();
				break;
			}
			// 点击了卫生间出去的开关
		case "WashRoomBack":
			{
				// 移动到客厅
				WashRoomDoorMove.instance.MoveLiving();
				break;
			}
			// 点击了书房出去的开关
		case "StudyRoomBack":
			{
				// 移动到客厅
				StudyRoomDoorMove.instance.MoveLiving();
				break;
			}
			// 点击了主卧出去的开关
		case "MainBedRoomBack":
			{
				// 移动到客厅
				MainBedRoomMove.instance.MoveLiving();
				break;
			}
			// 点击了次卧出去的开关
		case "MinorRoomBack":
			{
				// 移动到客厅
				MinorBedRoomMove.instance.MoveLiving();
				break;
			}
			// 点击厨房出去的开关
		case "DinnerRoomBack":
			{
				// 移动到客厅
				CameraMoveNav.instance.MoveLiving();
				break;
			}
		case "OK":
			{
				// 调用确定连接的方法
				MakeSure.instance.SubStart();
				break;
			}
			// 点击初始界面的Cancel
		case "Cancel":
			{
				// 调用取消连接的方法
				MakeSure.instance.Cancle();
				break;
			}

		}
	}
	#endregion
}


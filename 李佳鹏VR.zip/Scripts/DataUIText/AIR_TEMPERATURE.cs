﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 温度显示
/// </summary>
public class AIR_TEMPERATURE : MonoBehaviour {

	#region 定义的字段属性
	/// <summary>
	/// 显示温度的文本组件
	/// </summary>
	private Text text;

	/// <summary>
	/// 定义一个计时器
	/// </summary>
	float timer = 0f;

	/// <summary>
	/// 无连接的时候显示的内容
	/// </summary>
	int temperature = 0;
	#endregion

	#region Unity回调方法
	private void Start()
	{
		// 初始化文本组件
		text = this.GetComponent<Text>();
	}

	private void Update()
	{
		// 时间每帧增加一次
		timer += Time.deltaTime;
		// 数据每10秒改变一次
		if (timer >= 10f)
		{
			timer = 0f;
			SetValues();
		}    
	}
	#endregion

	#region 方法
	/// <summary>
	/// 显示虚拟数据的方法
	/// </summary>
	void SetValues()
	{
		// 温度虚拟值，在5-25之间随机取值
		temperature = Random.Range(5, 25);
		// 将值赋值给温度显示的text组件上
		text.text = temperature.ToString();
	}
	#endregion
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// 湿度显示
/// </summary>
public class AIR_HUMIDITY : MonoBehaviour {

	#region 字段属性
	/// <summary>
	/// 湿度显示的文本框
	/// </summary>
	private Text text;

	/// <summary>
	/// 定义一个计时器
	/// </summary>
	float timer = 0f;

	/// <summary>
	/// 文本框显示的数值定义
	/// </summary>
	int humidity = 0;
	#endregion

	#region Unity回调
	/// <summary>
	/// 初始化文本框
	/// </summary>
	private void Start()
	{
		// 初始化Text组件
		text = this.GetComponent<Text>();
	}

	private void Update()
	{

		timer += Time.deltaTime;
		// 每十秒变化一次
		if (timer >= 10f)
		{
			timer = 0f;
			SetValues();
		}
	}
	#endregion

	#region 方法
	// 无连接时随机显示数据
	void SetValues()
	{
		// 数值在5-25之间随机取值
		humidity = Random.Range(5, 25);
		// 将数值转化成为字符串形式，并显示在text上
		text.text = humidity.ToString();
	}
	#endregion
}

